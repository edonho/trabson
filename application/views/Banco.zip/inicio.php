<?php require_once("Padrao/header.php"); ?>
<div id="content">
    <aside class="propaganda1 back-gray">
        <img src="../estatico/img/bannertattoo.png" alt="propaganda tatuagem">
    </aside>
    
    <main class="inicio back-black-tp">
        <h1> Início </h1>
        <h2> Estúdios em destaque </h2>
        <?php require_once("Banco/listarEstudios.php"); ?>
        
        <!--<script src="..estatico/js/awesomstar.min.js"></script>-->
    </main>
    
    <aside class="propaganda2 back-gray">
        propaganda
        propaganda
    </aside>
</div>    
<?php require_once("Padrao/footer.php"); ?>

<!--40,88-->