<?php require_once("Padrao/header.php"); ?>
<meta charset="UTF-8">




<?php require_once("Padrao/footer.php"); ?>