<?php require_once("header.php"); ?>
        <footer class="footer">
            <span>Copyright Fatequinhos &copy;</span>
        </footer>
    </body>
</html>