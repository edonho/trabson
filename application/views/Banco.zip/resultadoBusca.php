<?php require_once("Padrao/header.php"); ?>
<div id="content">
    <aside class="propaganda1 back-gray">
        <p>Propaganda?</p>
        <p>Propaganda?</p>
        <p>Propaganda?</p>
        <p>Propaganda?</p>
    </aside>
    
    <main class="inicio back-black-tp">
        <h1> Estúdios </h1>
        <?php require_once("Banco/buscar.php"); ?>        
        
        <script src="../estatico/js/awesomstar.min.js"></script>
    </main>
    
    <aside class="propaganda2 back-gray">
        <p>Propaganda?</p>
        <p>Propaganda?</p>
        <p>Propaganda?</p>
        <p>Propaganda?</p>
    </aside>
</div>    
<?php require_once("Padrao/footer.php"); ?>