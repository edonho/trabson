<?php require_once("Padrao/header.php"); ?>





<?php require_once("Padrao/footer.php"); ?>