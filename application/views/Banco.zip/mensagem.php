<?php require_once("Padrao/header.php"); ?>

   <aside class="propaganda1 back-gray">
        <img src="../estatico/img/bannertattoo.png" alt="propaganda tatuagem">
    </aside>
    
    <main class="inicio back-black-tp">
        <h1> Mensagem </h1>
        <h2> Página em construção... </h2>
    </main>
    
    <aside class="propaganda2 back-gray">
        propaganda
        propaganda
    </aside>



<?php require_once("Padrao/footer.php"); ?>